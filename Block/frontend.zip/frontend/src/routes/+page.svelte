<script>
    import { auth } from '$lib/firebase';
    import { signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut } from 'firebase/auth';
    import { getFirestore, doc, getDoc } from 'firebase/firestore';

    const db = getFirestore();

    // Variables para el Administrador
    let adminEmail = '';
    let adminPassword = '';
    let adminMessage = '';
    let isAdminLoggedIn = false;

    // Variables para el Usuario
    let userEmail = '';
    let userPassword = '';
    let userMessage = '';
    let isUserLoggedIn = false;

    // Variable para alternar entre vistas
    let view = 'admin';

    // Función para iniciar sesión como administrador
    async function adminLogin() {
        try {
            const userCredential = await signInWithEmailAndPassword(auth, adminEmail, adminPassword);
            const userEmail = userCredential.user.email;

            // Verificar el rol en Firestore
            const docRef = doc(db, 'roles', userEmail);
            const docSnap = await getDoc(docRef);

            if (docSnap.exists() && docSnap.data().role === 'admin') {
                isAdminLoggedIn = true;
                adminMessage = 'Bienvenido, Admin';
            } else {
                adminMessage = 'No tienes permisos de administrador.';
            }
        } catch (error) {
            adminMessage = `Error: ${error.message}`;
        }
    }

    // Función para iniciar sesión como usuario
    async function userLogin() {
        try {
            const userCredential = await signInWithEmailAndPassword(auth, userEmail, userPassword);
            isUserLoggedIn = true;
            userMessage = `Bienvenido, ${userCredential.user.email}`;
        } catch (error) {
            userMessage = `Error: ${error.message}`;
        }
    }

    // Función para registrar usuarios
    async function registerUser() {
        try {
            const userCredential = await createUserWithEmailAndPassword(auth, userEmail, userPassword);
            userMessage = `Cuenta creada: ${userCredential.user.email}`;
        } catch (error) {
            userMessage = `Error: ${error.message}`;
        }
    }

    // Función para cerrar sesión
    async function logout() {
        try {
            await signOut(auth);
            isAdminLoggedIn = false;
            isUserLoggedIn = false;
            adminMessage = '';
            userMessage = '';
        } catch (error) {
            console.error('Error al cerrar sesión:', error.message);
        }
    }
</script>

<div class="container mx-auto mt-10">
    <h1 class="text-3xl font-bold mb-6 text-center">Certificación de Documentos</h1>

    <!-- Botones para alternar entre Admin y Usuario -->
    <div class="flex justify-center mb-6 space-x-4">
        <button
            on:click={() => (view = 'admin')}
            class="px-4 py-2 rounded bg-blue-500 text-white font-semibold"
        >
            Administrador
        </button>
        <button
            on:click={() => (view = 'user')}
            class="px-4 py-2 rounded bg-green-500 text-white font-semibold"
        >
            Usuario
        </button>
    </div>

    <!-- Vista del Administrador -->
    {#if view === 'admin'}
        {#if isAdminLoggedIn}
            <div class="p-4 border rounded shadow">
                <h2 class="text-xl font-bold mb-4">Panel del Administrador</h2>
                <p>Bienvenido al sistema. Aquí puedes gestionar certificados.</p>
                <button
                    on:click={logout}
                    class="bg-red-500 text-white px-4 py-2 rounded w-full mt-4"
                >
                    Cerrar Sesión
                </button>
            </div>
        {:else}
            <div class="p-4 border rounded shadow">
                <h2 class="text-xl font-bold mb-4">Login Administrador</h2>
                <input
                    type="email"
                    bind:value={adminEmail}
                    placeholder="Correo Electrónico"
                    class="w-full p-2 border rounded mb-4"
                />
                <input
                    type="password"
                    bind:value={adminPassword}
                    placeholder="Contraseña"
                    class="w-full p-2 border rounded mb-4"
                />
                <button
                    on:click={adminLogin}
                    class="bg-blue-500 text-white px-4 py-2 rounded w-full"
                >
                    Iniciar Sesión
                </button>
                {#if adminMessage}
                    <p class="mt-4 text-green-500">{adminMessage}</p>
                {/if}
            </div>
        {/if}
    {/if}

    <!-- Vista del Usuario -->
    {#if view === 'user'}
        {#if isUserLoggedIn}
            <div class="p-4 border rounded shadow">
                <h2 class="text-xl font-bold mb-4">Panel del Usuario</h2>
                <p>Bienvenido al sistema. Aquí puedes verificar tus certificados.</p>
                <button
                    on:click={logout}
                    class="bg-red-500 text-white px-4 py-2 rounded w-full mt-4"
                >
                    Cerrar Sesión
                </button>
            </div>
        {:else}
            <div class="p-4 border rounded shadow">
                <h2 class="text-xl font-bold mb-4">Login Usuario</h2>
                <input
                    type="email"
                    bind:value={userEmail}
                    placeholder="Correo Electrónico"
                    class="w-full p-2 border rounded mb-4"
                />
                <input
                    type="password"
                    bind:value={userPassword}
                    placeholder="Contraseña"
                    class="w-full p-2 border rounded mb-4"
                />
                <button
                    on:click={userLogin}
                    class="bg-gray-500 text-white px-4 py-2 rounded w-full mb-4"
                >
                    Iniciar Sesión
                </button>
                <h2 class="text-xl font-bold mb-4">Crear Cuenta</h2>
                <button
                    on:click={registerUser}
                    class="bg-green-500 text-white px-4 py-2 rounded w-full"
                >
                    Crear Cuenta
                </button>
                {#if userMessage}
                    <p class="mt-4 text-green-500">{userMessage}</p>
                {/if}
            </div>
        {/if}
    {/if}
</div>

<style>
    .container {
        max-width: 800px;
    }
</style>
